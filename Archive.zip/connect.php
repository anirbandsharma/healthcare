<?php

$server = "localhost";
$username1 = "root1";
$password = "pass";
$database = "healthcare";

$con=mysqli_connect($server,$username1,$password,$database)or die("can't connect...");
?>
